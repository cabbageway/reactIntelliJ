import React from 'react';
import {ICounter} from "../models/Interfaces";

function Zaehler2({count, onChangeNumber}:ICounter) {
    return (
        <div>
            <h2>Zähler über fremde Komponente</h2>
            <button onClick={ () => onChangeNumber(++count)}>rise2</button>
            <hr/>
        </div>
    );
}

export default Zaehler2;