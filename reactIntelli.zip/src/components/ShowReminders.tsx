import React from 'react';
import {IReminder, IReminders} from "../models/Interfaces";

//function ShowReminders(props:IReminders) {
function ShowReminders({reminders}:IReminders) {

    return (
        <div>
            <hr/>
            <h2>Show Reminders Komponente</h2>
            <ul>
            {reminders.map((item:IReminder) =>
                <li key={item.id}><span className='badge bg-secondary'>
                {item.who}
                </span></li>)}
            </ul>
        </div>
    );
}

export default ShowReminders;