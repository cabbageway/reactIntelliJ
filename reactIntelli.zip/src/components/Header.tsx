import React from 'react';

function Header() {
    return (
        <div>
            <h1>aus dem Header</h1>
        </div>
    );
}

export default Header;

